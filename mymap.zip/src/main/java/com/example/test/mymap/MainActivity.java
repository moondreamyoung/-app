package com.example.test.mymap;




import android.Manifest;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.baidu.mapapi.SDKInitializer;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapStatus;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.model.LatLng;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
    private MapView mMapView ;
    public static final int      REQ_CODE_CONTACT = 1;//定义短信查询常量
    int i,i1,i2,i3,i4,i5=0;//定义统计报警个数常量
    public String s="water stage warning,number:";//定义要判断的开头字符串
    private static final String TEMP_INFO="temp_info";//定义SharedPreference常量
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SDKInitializer.initialize(getApplicationContext());
        setContentView(R.layout.activity_main);
        mMapView = (MapView) findViewById(R.id.bmapView);//获取地图控件引用
        BaiduMap mBaiduMap = mMapView.getMap();
        LatLng cenpt = new LatLng(24.68,108.03);//设定中心点坐标
        MapStatus mMapStatus = new MapStatus.Builder()
                .target(cenpt)
                .zoom(15)
                .build();//定义MapStatusUpdate对象，以便描述地图状态将要发生的变化
        MapStatusUpdate mMapStatusUpdate = MapStatusUpdateFactory.newMapStatus(mMapStatus);//改变地图状态
        mBaiduMap.setMapStatus(mMapStatusUpdate);//更新地图


        checkSMSPermission();//检查短信权限
    }

    /**
     * 检查申请短信权限
     */
    private void checkSMSPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            //未获取到读取短信权限

            //向系统申请权限
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_SMS}, REQ_CODE_CONTACT);
        } else {
            query();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //判断用户是否，同意 获取短信授权
        if (requestCode == REQ_CODE_CONTACT && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            //获取到读取短信权限
            query();
        } else {
            Toast.makeText(this, "未获取到短信权限", Toast.LENGTH_SHORT).show();
        }
    }

    private void query() {//遍历短信库

        //读取所有短信
        Uri uri = Uri.parse("content://sms/");
        ContentResolver resolver = getContentResolver();
        String where = " date > "
                + (System.currentTimeMillis() - 30*60*1000);//定义遍历范围
        Cursor cursor = resolver.query(uri, new String[]{"_id", "address", "body", "date", "type"}, where, null, null);
        //获取短信的id address内容等
        if (cursor != null && cursor.getCount() > 0) {
            int _id;
            String address;
            String body;
            String date;
            int type;
            while (cursor.moveToNext()) {
                _id = cursor.getInt(0);
                address = cursor.getString(1);
                body = cursor.getString(2);
                date = cursor.getString(3);
                type = cursor.getInt(4);
                Log.i("test", "_id=" + _id + " address=" + address + " body=" + body + " date=" + date + " type=" + type);
                //测试log可以删除
                BaiduMap mBaiduMap = mMapView.getMap();//获取地图控件引用
                BitmapDescriptor bdA = BitmapDescriptorFactory
                        .fromResource(R.drawable.icon_mark);//定义报警点图标

                SharedPreferences sp=getSharedPreferences(TEMP_INFO, Context.MODE_PRIVATE);//获取设置中存储的内容
                String w1=sp.getString("info_content1","");
                //w1表示第一个点的纬度，j1表示第一个点的经度，w2表示第二个点的纬度，以此类推
                String j1=sp.getString("info_content2","");
                String w2=sp.getString("info_content3","");
                String j2=sp.getString("info_content4","");
                String w3=sp.getString("info_content5","");
                String j3=sp.getString("info_content6","");
                String w4=sp.getString("info_content7","");
                String j4=sp.getString("info_content8","");
                String w5=sp.getString("info_content9","");
                String j5=sp.getString("info_content10","");
                //这些是获取second活动中传来的string值


                double zuobiaow1=Double.parseDouble(w1);
                double zuobiaoj1=Double.parseDouble(j1);
                double zuobiaow2=Double.parseDouble(w2);
                double zuobiaoj2=Double.parseDouble(j2);
                double zuobiaow3=Double.parseDouble(w3);
                double zuobiaoj3=Double.parseDouble(j3);
                double zuobiaow4=Double.parseDouble(w4);
                double zuobiaoj4=Double.parseDouble(j4);
                double zuobiaow5=Double.parseDouble(w5);
                double zuobiaoj5=Double.parseDouble(j5);
                //将获取到的string值转化成double类型

                List<OverlayOptions> options = new ArrayList<OverlayOptions>();
                //获取list控件引用
                LatLng point1 = new LatLng(zuobiaow1, zuobiaoj1);
                LatLng point2 = new LatLng(zuobiaow2, zuobiaoj2);
                LatLng point3 = new LatLng(zuobiaow3,zuobiaoj3);
                LatLng point4 = new LatLng(zuobiaow4,zuobiaoj4);
                LatLng point5 = new LatLng(zuobiaow5,zuobiaoj5);
                //五个点的坐标经纬度

//创建OverlayOptions属性

                OverlayOptions option1 = new MarkerOptions()
                        .position(point1)
                        .icon(bdA);
                //把第一个点的坐标和图标绑定在一起
                OverlayOptions option2 = new MarkerOptions()
                        .position(point2)
                        .icon(bdA);
                OverlayOptions option3 = new MarkerOptions()
                        .position(point3)
                        .icon(bdA);
                OverlayOptions option4 = new MarkerOptions()
                        .position(point4)
                        .icon(bdA);
                OverlayOptions option5 = new MarkerOptions()
                        .position(point5)
                        .icon(bdA);

                options.add(option1);
                options.add(option2);
                options.add(option3);
                options.add(option4);
                options.add(option5);
                //将OverlayOptions添加到list


                Pattern r = Pattern.compile(s);
                Matcher m = r.matcher(body);
                //初始化正则表达式

                if(m.find())
                {
                    String regEx="[^0-9]";
                    Pattern p=Pattern.compile(regEx);
                    Matcher m1=p.matcher(body);
                    String str=m1.replaceAll("").trim();
                    int message=Integer.valueOf(str).intValue();
                    //利用正则表达式提取短信中的内容,如果短信中开头符合string量s，则提取s后面的数字，
                    //并与整型变量message比较，如果相等，则显示坐标

                    int message1=1;
                    int message2=2;
                    int message3=3;
                    int message4=4;
                    int message5=5;
                    if (message==message1){mBaiduMap.addOverlay(option1);if(i1==1)break;else i1=i1+1;}
                    //这里的i1是为了检测坐标1是否已经报警
                    if(message==message2){mBaiduMap.addOverlay(option2);if(i2==1)break;else i2=i2+1;}
                    if(message==message3){mBaiduMap.addOverlay(option3);if(i3==1)break;else i3=i3+1;}
                    if(message==message4){mBaiduMap.addOverlay(option4);if(i4==1)break;else i4=i4+1;}
                    if(message==message5){mBaiduMap.addOverlay(option5);if(i5==1)break;else i5=i5+1;}


                }
            }
        }
        i=i1+i2+i3+i4+i5;//统计已经报警的个数
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_layout,menu);
        return true;
    }//创建活动菜单

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.exit:
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(0);//离开按钮
            case R.id.remove_sign:
                BaiduMap mBaiduMap = mMapView.getMap();
                mBaiduMap.clear();
                i=0;//取消报警，并初始化计数变量
            case R.id.show:
                Toast.makeText(this,"个数为"+i+"个",Toast.LENGTH_SHORT).show();
                break;//显示报警个数按钮
            case R.id.nextactivity_item:
                Intent intent=new Intent(MainActivity.this,second.class);
                startActivity(intent);//跳转到second活动
                break;
                default:
        }
        return true;
    }





    @Override
    protected void onDestroy() {
        super.onDestroy();
        //在activity执行onDestroy时执行mMapView.onDestroy()，实现地图生命周期管理
        mMapView.onDestroy();
    }
    @Override
    protected void onResume() {
        super.onResume();
        //在activity执行onResume时执行mMapView. onResume ()，实现地图生命周期管理
        mMapView.onResume();
    }
    @Override
    protected void onPause() {
        super.onPause();
        //在activity执行onPause时执行mMapView. onPause ()，实现地图生命周期管理
        mMapView.onPause();

    }
}

package com.example.test.mymap;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;

public class second extends MainActivity {
    EditText zbw1,zbj1,zbw2,zbj2,zbw3,zbj3,zbw4,zbj4,zbw5,zbj5;
    private static final String TEMP_INFO="temp_info";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        zbw1=(EditText)findViewById(R.id.zbw1);
        //这里的zbw1指的坐标1的纬度，zbj1是坐标1经度，zbw2是坐标2纬度，以此类推
        zbj1=(EditText)findViewById(R.id.zbj1);
        zbw2=(EditText)findViewById(R.id.zbw2);
        zbj2=(EditText)findViewById(R.id.zbj2);
        zbw3=(EditText)findViewById(R.id.zbw3);
        zbj3=(EditText)findViewById(R.id.zbj3);
        zbw4=(EditText)findViewById(R.id.zbw4);
        zbj4=(EditText)findViewById(R.id.zbj4);
        zbw5=(EditText)findViewById(R.id.zbw5);
        zbj5=(EditText)findViewById(R.id.zbj5);
        SharedPreferences sp = getSharedPreferences(TEMP_INFO, Context.MODE_PRIVATE);
        //将值传给sharedpreference
        String content1 = sp.getString("info_content1", "");
        String content2 = sp.getString("info_content2", "");
        String content3 = sp.getString("info_content3", "");
        String content4 = sp.getString("info_content4", "");
        String content5 = sp.getString("info_content5", "");
        String content6 = sp.getString("info_content6", "");
        String content7 = sp.getString("info_content7", "");
        String content8 = sp.getString("info_content8", "");
        String content9 = sp.getString("info_content9", "");
        String content10 = sp.getString("info_content10", "");
        //获取字符串值
        if(content1.equals(""))content1="0";
        if(content2.equals(""))content2="0";
        if(content3.equals(""))content3="0";
        if(content4.equals(""))content4="0";
        if(content5.equals(""))content5="0";
        if(content6.equals(""))content6="0";
        if(content7.equals(""))content7="0";
        if(content8.equals(""))content8="0";
        if(content9.equals(""))content9="0";
        if(content10.equals(""))content10="0";
        //赋予默认string值，不能为空，否则程序崩溃
        zbw1.setText(content1);
        zbj1.setText(content2);
        zbw2.setText(content3);
        zbj2.setText(content4);
        zbw3.setText(content5);
        zbj3.setText(content6);
        zbw4.setText(content7);
        zbj4.setText(content8);
        zbw5.setText(content9);
        zbj5.setText(content10);
        //保存string值
    }
    protected void onStop(){
        super.onStop();
        SharedPreferences.Editor editor = getSharedPreferences(TEMP_INFO,Context.MODE_PRIVATE).edit();
        editor.putString("info_content1", zbw1.getText().toString());
        editor.putString("info_content2", zbj1.getText().toString());
        editor.putString("info_content3", zbw2.getText().toString());
        editor.putString("info_content4", zbj2.getText().toString());
        editor.putString("info_content5", zbw3.getText().toString());
        editor.putString("info_content6", zbj3.getText().toString());
        editor.putString("info_content7", zbw4.getText().toString());
        editor.putString("info_content8", zbj4.getText().toString());
        editor.putString("info_content9", zbw5.getText().toString());
        editor.putString("info_content10", zbj5.getText().toString());
        editor.commit();
        //将输入的string值传输给主活动
    }

}
